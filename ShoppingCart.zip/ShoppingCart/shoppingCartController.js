  shoppingCartModule.controller('shoppingCartController',function($scope,productDataSVC){
                   
    $scope.ProductList = productDataSVC.getProducts();

            //         $scope.ProductList = [
            //         {
            //             Name:'Mobile',                    
            //             Price:10000,
            //             ImageUrl:'https://cf-catman.infibeam.net/img/m1/lenovok4notefront.jpg.993ea97715.999x450x573.jpg.999xx.jpg',
            //             Quantity:100,
            //             Rating:4,
            //             Likes:10
            //     },
            //  {
            //             Name:'Laptop',                    
            //             Price:40000,
            //             ImageUrl:'http://ssl-product-images.www8-hp.com/digmedialib/prodimg/lowres/c04462268.png',
            //             Quantity:200,
            //             Rating:3,
            //                 Likes:30
            //     },
            //          {
            //             Name:'LED TV',                    
            //             Price:30000,
            //             ImageUrl:'http://im.rediff.com/gadget/2015/feb/Weston.jpg',
            //             Quantity:800,
            //             Rating:4,
            //                 Likes:50
            //     },
            //          {
            //             Name:'Camera',                    
            //             Price:90000,
            //             ImageUrl:'https://www.bhphotovideo.com/images/categoryImages/desktop/325x325/21008-DSLR-Cameras.jpg',
            //             Quantity:70,
            //             Rating:3.5,
            //                 Likes:30
            //     },
            //          {
            //             Name:'PS 2',                    
            //             Price:20000,
            //             ImageUrl:'https://psmedia.playstation.com/is/image/psmedia/ps2-hardware-two-column-01-ps4-eu-18nov15?$TwoColumn_Image$',
            //             Quantity:10,
            //             Rating:2.8988,
            //                 Likes:90
            //     }    
            // ];// eof product List

            $scope.IncrementLikes = function  (p){
                    // change the model !
                    p.Likes++;
            }

            $scope.DecrementLikes =  function  (p){
                    // change the model !
                    p.Likes--;
            }

            $scope.filterCompany = '';

            $scope.Companies = [
                {Name:'Fiserv',Location:'Pune'},
                {Name:'Accenture',Location:'Hyderabad'},
                {Name:'Accenture',Location:'Pune'},
                {Name:'Fiserv',Location:'Bengaluru'},
                {Name:'Synechron',Location:'Hyderabad'}     

            ];

            $scope.Cities = [
                    {Name:'Hyderabad',Speciality:'Biryani'},
                    {Name:'Pune',Speciality:'Misal Pav'},
                    {Name:'Mumbai',Speciality:'Wada Pav'},
                    {Name:'Nagpur',Speciality:'Tarri Poha'}                    
                ];


            });